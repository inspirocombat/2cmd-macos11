#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "usage: $0 VERSION SHA256" >&2
  exit 2
fi

version=$1
sha256=$2

cat <<EOF
cask "2cmd" do
  version "$version"
  sha256 "$sha256"

  url "https://github.com/tonatoz/2cmd/releases/download/v#{version}/2cmd.dmg"
  name "2cmd"
  desc "Switch keyboard layouts with the left and right Command keys"
  homepage "https://github.com/tonatoz/2cmd"

  livecheck do
    url :url
    strategy :github_latest
  end

  depends_on macos: ">= :big_sur"

  app "2cmd.app"

  # Homebrew quarantines every download, unconditionally: the --no-quarantine flag
  # and its HOMEBREW_CASK_OPTS equivalent were removed in July 2026. A quarantined
  # build signed with an unknown certificate chain is spawned and then held by
  # Gatekeeper before main() runs, so the app appears in Activity Monitor with no
  # menu bar icon and no window. Dropping the flag here is what makes the app
  # launchable at all until the release is notarized.
  postflight_steps do
    run "/usr/bin/xattr",
        args: ["-dr", "com.apple.quarantine", "{{appdir}}/2cmd.app"]
  end

  uninstall quit: "dev.anton.2cmd"

  zap trash: "~/Library/Preferences/dev.anton.2cmd.plist"

  caveats <<~EOS
    2cmd is signed with a project certificate and is not notarized, so this cask
    clears the quarantine flag Homebrew attaches to the download — otherwise
    Gatekeeper holds the app before it starts and it never reaches the menu bar.

    Then enable 2cmd in System Settings → Privacy & Security → Accessibility.
  EOS
end
EOF
