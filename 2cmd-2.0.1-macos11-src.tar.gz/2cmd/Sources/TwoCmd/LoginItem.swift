import Foundation
import ServiceManagement

/// Launch at login. `SMAppService` exists only on macOS 13+; older systems
/// (macOS 11–12) get a per-user LaunchAgent that opens the app bundle at login.
enum LoginItem {
    private static let label = "dev.anton.2cmd"

    private static var agentURL: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/LaunchAgents/\(label).plist")
    }

    static var isEnabled: Bool {
        if #available(macOS 13, *) { return SMAppService.mainApp.status == .enabled }
        return FileManager.default.fileExists(atPath: agentURL.path)
    }

    static func setEnabled(_ enabled: Bool) throws {
        if #available(macOS 13, *) {
            let service = SMAppService.mainApp
            if enabled { try service.register() } else { try service.unregister() }
            return
        }
        guard enabled else {
            try FileManager.default.removeItem(at: agentURL)
            return
        }
        let plist: [String: Any] = [
            "Label": label,
            "ProgramArguments": ["/usr/bin/open", Bundle.main.bundlePath],
            "RunAtLoad": true,
        ]
        try FileManager.default.createDirectory(
            at: agentURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        try PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0)
            .write(to: agentURL, options: .atomic)
    }
}
